C&B MACHINERY / FILM DIRECTION V2

START HERE: SCRIPT.md, then OPUS-HANDOFF.md.
Eight 1920 x 1080 keyframes are in keyframes/.
This package contains art direction and renderable still scenes, not a finished video.

PREVIEW THE EDITABLE KEYFRAMES
From this extracted folder run:
python3 -m http.server 8094 --bind 127.0.0.1 --directory dist
Open http://127.0.0.1:8094/overview/film-v2/frame.html?frame=1
Change frame=1 through frame=8. For export use a 1920 x 1080 viewport.
Wait for equipment textures and images to finish loading before capture.
The HTML / CSS / JavaScript text and layout layers remain editable.

FULL INTERACTIVE WORKFLOW
https://kyle-annora.github.io/cbmachinery-demo-preview/overview/
The kit includes only dependencies required to reproduce the still scenes.
Other source-map paths in the production notes refer to the full source repository.
Final video production should capture verified interactions from the full demo.

DELIVERY STATUS
Final animation, audio, captions and encoded video are pending production.
Keep real equipment, schematic internals and proposed website behavior distinct.
All interface examples are fictional. No inquiry, email or commercial acceptance is sent.
